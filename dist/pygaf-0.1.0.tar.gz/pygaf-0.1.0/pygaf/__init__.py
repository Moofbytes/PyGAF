
"""
PyGAF - Python Groundwater Analytic Flow.

Python package for evaluation and display of analytic solutions for
groundwater flow.

Repository: https://github.com/Moofbytes/PyGAF
Documentation: https://pygaf.readthedocs.io/en/latest/index.html

"""

from .aquifers import (
    Aquifer,
    Aq2dConf,
    Aq2dLeaky,
    Aq2dUnconf,
    Aq1dFiniteConf,
    Aq1dFiniteUnconf,
    Aq1dSemifiniteConf,
    Aq1dSemifiniteUnconf
 )

from .wells import (
    Well,
    SteadyWell,
    TransientWell
)

from .stresses import (
    StressSeries
)

from .grids import (
    SteadyWellGrid,
    BasinGrid
)

from .basins import (
    RectBasin,
    CircBasin
)

from .bcs import (
    SteadyBC
)

from .solutions import *

import pygaf.utils
